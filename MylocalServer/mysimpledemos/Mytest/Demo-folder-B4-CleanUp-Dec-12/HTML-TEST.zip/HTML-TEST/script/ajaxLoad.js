function ajaxLoad(url){
			jQuery(".css-panes").load(url, function(response, status, xhr) {});
		}