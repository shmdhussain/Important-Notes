var jsonobj={val:["hi","bye"]};
jsonobj.stringify()


var jsonobj={[{"hi","bye"},{"x","y"}]};

1 keyvalue pair or set of key value pair

2. objects

3.